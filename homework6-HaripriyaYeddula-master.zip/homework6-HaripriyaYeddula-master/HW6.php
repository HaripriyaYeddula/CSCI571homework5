<?php
if(isset($_GET["similarItems"]))
{
  #$itemId = 413319740355;
  $itemId = $_GET["itemId"];
  $url = "http://svcs.ebay.com/MerchandisingService?OPERATION-NAME=getSimilarItems&SERVICE-NAME=MerchandisingService&SERVICE-VERSION=1.1.0&CONSUMER-ID=Haripriy-ProductS-PRD-116e557a4-83799a68&siteid=0&version=967&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&itemId=".$itemId."&maxResults=8";
  $similarItems = file_get_contents($url);
  echo $similarItems;
  exit;
}
if(isset($_GET["itemdetails"]))
{
  #$itemId = 113661399317;
  $itemId = $_GET["itemId"];
  $url = "http://open.api.ebay.com/shopping?callname=GetSingleItem&responseencoding=JSON&appid=Haripriy-ProductS-PRD-116e557a4-83799a68&siteid=0&version=967&ItemID=".$itemId."&IncludeSelector=Description,Details,ItemSpecifics";
  $singleitemdata = file_get_contents($url);
  echo $singleitemdata;
  exit;
}
if(isset($_GET["action"])){
  $categoryId = "";$distance="";$keywords="";$zip="";$i = 0;
  $endpoint ="http://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=Haripriy-ProductS-PRD-116e557a4-83799a68&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&paginationInput.entriesPerPage=20";

  if(isset($_GET["keyword"])){
    $keywords = urlencode($_GET['keyword']);
    $endpoint = $endpoint."&keywords=".$keywords;

  }
  if(isset($_GET["category"])){
      $category = $_GET['category'];
      switch ($category) {
        case 'Art':
          $categoryId = urlencode(550);
          break;
        case 'Baby':
          $categoryId = urlencode(2984);
          break;
        case 'Books':
          $categoryId = urlencode(267);
          break;
        case 'Clothing, Shoes N Accessories':
          $categoryId = urlencode(11450);
          break;
        case 'Computers/Tablets N Networking':
          $categoryId = urlencode(58058);
          break;
        case 'Health N Beauty':
          $categoryId = urlencode(26395);
          break;
        case 'Music':
          $categoryId = urlencode(11233);
          break;
        case 'Video Games N Consoles':
          $categoryId = urlencode(1249);
          break;
      }
      $endpoint = $endpoint."&categoryId=".$categoryId;
  }

  if(isset($_GET["zip"])){
    $zip = $_GET['zip'];
    $endpoint = $endpoint."&buyerPostalCode=".$zip;
  }
  $endpoint = $endpoint."&itemFilter(".$i.").name=HideDuplicateItems&itemFilter(".$i.").value=true";
  $i++;
  if(isset($_GET["distance"])){
    $distance = $_GET['distance'];
    $endpoint = $endpoint."&itemFilter(".$i.").name=MaxDistance&itemFilter(".$i.").value=".$distance;
    $i++;
  }
  if(isset($_GET["shipping"])){
    $shipping_options = $_GET['shipping'];
    if ($shipping_options == "Local") {
      $endpoint =  $endpoint."&itemFilter(".$i.").name=LocalPickupOnly&itemFilter(".$i.").value=true";
      $i++;
      $endpoint =  $endpoint."&itemFilter(".$i.").name=FreeShippingOnly&itemFilter(".$i.").value=false";
      $i++;
    }if ($shipping_options == "Free Shipping") {
      $endpoint =  $endpoint."&itemFilter(".$i.").name=LocalPickupOnly&itemFilter(".$i.").value=false";
      $i++;
      $endpoint =  $endpoint."&itemFilter(".$i.").name=FreeShippingOnly&itemFilter(".$i.").value=true";
      $i++;
    }
}

  if(isset($_GET["condition"])){
    $endpoint = $endpoint."&itemFilter(".$i.").name=Condition";
    $condition = $_GET['condition'];
    if ($condition == "All") {
        $endpoint = $endpoint."&itemFilter(".$i.").value(0)=New";
        $endpoint = $endpoint."&itemFilter(".$i.").value(1)=Used";
        $endpoint = $endpoint."&itemFilter(".$i.").value(2)=Unspecified";
    }
    else if ($condition == "NewNUsed") {
        $endpoint = $endpoint."&itemFilter(".$i.").value(0)=New";
        $endpoint = $endpoint."&itemFilter(".$i.").value(1)=Used";
    }
    else if ($condition == "UsedNUnspecified") {
        $endpoint = $endpoint."&itemFilter(".$i.").value(0)=Used";
        $endpoint = $endpoint."&itemFilter(".$i.").value(1)=Unspecified";
    }
    else if ($condition == "UnspecifiedNNew") {
        $endpoint = $endpoint."&itemFilter(".$i.").value(0)=New";
        $endpoint = $endpoint."&itemFilter(".$i.").value(1)=Unspecified";
    }
    else
        $endpoint = $endpoint."&itemFilter(".$i.").value=". $condition;
    $i++;
  }
$data= file_get_contents($endpoint);
#echo $endpoint;
echo $data;
exit;
}
?>
<html>
<head><title>Product Search</title>
<style>
*{
  box-sizing: border-box;
  margin-top: 10px;
  margin-left: 5px;
}
input:disabled {
  background: #dddddd;
}
input:disabled+label {
  color: #ccc;
}
input[type=text]+label {
  float: left;
}
#search_form {
  margin: auto;
  width: 600px;
  background-color: #f2f2f2;
  border: 2px solid lightgrey;
}
#search_form p {
  position: relative;
  margin: auto;
  width: 580px;
  text-align: center;
  font-style: italic;
  font-size: 33px;
  border-bottom: 2px solid lightgrey;
}
#category{
  width: 220px;
}
#buttons{
  position: relative;
  margin: auto;
  width: 400px;
  margin-top: 10px;
  margin-bottom: 20px;
  text-align: center;
}
#search, #clear{
  padding: 3px;
}
#zip{
  margin-left: 350.5px;
}
#miles{
  width:50px;
  margin-left: 25px;
}
#cond{
  margin-left: 20px;
}
#soptions{
  margin-left: 39px;
}
</style>

<script type="text/javascript">
var Here;
function findgeoLocation(){
  var url = 'http://ip-api.com/json';
  var request=new XMLHttpRequest();
  request.open("GET",url, false);
  request.send();
  var location = JSON.parse(request.responseText);
  Here = location.zip;
  document.getElementById("search").disabled = false;
  clearForm(document.getElementById("search_form"));
  togglefields(document.getElementById("nearbysearch"));
}
function togglefields(nearbysearch){
  var enableeles = document.getElementsByClassName("toenable");
  for (var i = 0; i < enableeles.length; i++) {
      enableeles[i].disabled = !nearbysearch.checked;
  }
  document.getElementById("textzip").value = "";
  document.getElementById("textzip").readOnly = true;
  document.getElementById("here").checked = true;
  document.getElementById("miles").value = "";
}
function clearForm(myform){
  form_elements=myform.elements;
  for (i = 0; i < form_elements.length; i++)
  {
    field_type = form_elements[i].type.toLowerCase();
    switch (field_type)
    {
    case "text":
    case "password":
    case "textarea":
        form_elements[i].value = "";
        break;
    case "radio":
    case "checkbox":
        if (form_elements[i].checked)
            form_elements[i].checked = false;
        break;
    case "select-one":
    case "select-multi":
        form_elements[i].selectedIndex = 0;
        break;
    default:
        break;
    }
    if(document.getElementById("displaymsgdiv"))
      document.getElementById("displaymsgdiv").remove();
    document.getElementById("ihead").innerHTML = "";
    document.getElementById("resultTable").innerHTML = "";
    document.getElementById("forbtns").innerHTML = "";
    document.getElementById("forbtns2").innerHTML = "";
 }
 togglefields(document.getElementById("nearbysearch"));
}
function validateZip(){
  var zipinput = document.getElementById("textzip").value;
  var validzip = /^[0-9]{5}(?:-[0-9]{4})?$/.test(zipinput);
    if (!validzip){
      displayMessages("Zipcode is Invalid");
      return false;
    }
    else
      return true;
}
function displayMessages(textToShow){
  document.getElementById("resultTable").innerHTML = "";
  document.getElementById("forbtns").innerHTML = "";
  document.getElementById("forbtns2").innerHTML = "";
  if(document.getElementById("displaymsgdiv"))
    document.getElementById("displaymsgdiv").remove();
  var msgToShow = document.createElement("div");
  msgToShow.id = "displaymsgdiv";
  msgToShow.innerHTML = "";
  msgToShow.style.width = "1000px";
  msgToShow.style.margin = "auto";
  msgToShow.style.border = "2px solid lightgrey";
  msgToShow.style.textAlign = "center";
  msgToShow.style.backgroundColor = "#f2f2f2";
  var msgText = document.createTextNode(textToShow);
  msgToShow.appendChild(msgText);
  document.body.appendChild(msgToShow);
}
function sendInfo(form){
  if(document.getElementById("displaymsgdiv"))
    document.getElementById("displaymsgdiv").remove();
  var msgToShow = document.createElement("div");
  msgToShow.id = "displaymsgdiv";
  msgToShow.innerHTML = "";
  document.getElementById("forbtns").innerHTML = "";
  document.getElementById("forbtns2").innerHTML = "";
  document.getElementById("ihead").innerHTML = "";
  document.getElementById("resultTable").innerHTML = "";
  if(document.getElementById("zip").checked)
       var zipcodevalidity = validateZip();
  var shipping, condition, distance=10, zip=Here;
  var keyword=document.getElementById("keyword").value;
  if (keyword.length < 2)
      displayMessages("Invalid keyword");
  else{
    var category=document.getElementById("category").options[document.getElementById("category").selectedIndex].text;
    category = category.replace("&","N");

    if(document.getElementById("new").checked && !document.getElementById("used").checked && !document.getElementById("none").checked)
        condition = "New"
    else if(!document.getElementById("new").checked && document.getElementById("used").checked && !document.getElementById("none").checked)
        condition = "Used"
    else if(!document.getElementById("new").checked && !document.getElementById("used").checked && document.getElementById("none").checked)
        condition = "Unspecified";
    else if(document.getElementById("new").checked && document.getElementById("used").checked && !document.getElementById("none").checked)
        condition = "NewNUsed";
    else if(!document.getElementById("new").checked && document.getElementById("used").checked && document.getElementById("none").checked)
        condition = "UsedNUnspecified";
    else if(document.getElementById("new").checked && !document.getElementById("used").checked && document.getElementById("none").checked)
        condition = "UnspecifiedNNew";
    else
        condition = "All";

    if(document.getElementById("local").checked && !document.getElementById("ship").checked)
      shipping = "Local";
    if (document.getElementById("ship").checked && !document.getElementById("local").checked)
      shipping = "Free Shipping";

    if (document.getElementById("nearbysearch").checked) {
      distance = document.getElementById("miles").value;
      if(distance=="")
        distance = 10;
      if(!document.getElementById("here").checked)
        zip = document.getElementById("textzip").value;
      else
        zip = Here;
    }

    if(zipcodevalidity!=false){
      var request = new XMLHttpRequest();

      if (document.getElementById("nearbysearch").checked)
        var params = "keyword="+keyword+"&condition="+condition+"&shipping="+shipping+"&distance="+distance+"&isNearByChecked=true"+"&zip="+zip+"&action=true";
      else
        var params = "keyword="+keyword+"&condition="+condition+"&shipping="+shipping+"&isNearByChecked=false"+"&action=true";

      if (category != "All Categories")
        params = params + "&category="+category ;

      var url = "/HW6.php?"+ params;
      request.open("GET", url, false);
      request.send();
      var data = JSON.parse(request.responseText);
      if((data["findItemsAdvancedResponse"]==undefined)||(data["findItemsAdvancedResponse"]["0"]==undefined)||(data["findItemsAdvancedResponse"]["0"]["searchResult"]==undefined)||(data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]==undefined)
      ||(data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["@count"]==undefined)||(data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["@count"]==0)||data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"]==undefined)
      {
          displayMessages("No Records has been found");
      }
      else
          displayResults(data);
    }
  }
}
function toggleTextfield(ziptextfield){
  document.getElementById(ziptextfield.id).value = "";
  document.getElementById(ziptextfield.id).readOnly = !document.getElementById(ziptextfield.id).readOnly;
}
function getSingleItem(itemIdparam){
  var request = new XMLHttpRequest();
  var itemdetailsurl ="/HW6.php?itemdetails=true&itemId=" +itemIdparam;
  request.open("GET",itemdetailsurl, false);
  request.send();
  var singleitemdata = JSON.parse(request.responseText);

  if(singleitemdata.hasOwnProperty('Errors')){
    if( singleitemdata["Errors"] != undefined || singleitemdata["Errors"] != null || singleitemdata["Errors"] != "" || singleitemdata["Errors"]["0"] != undefined ||
      singleitemdata["Errors"]["0"] != null || singleitemdata["Errors"]["0"] != "" || singleitemdata["Errors"]["0"]["LongMessage"] != undefined ||
      singleitemdata["Errors"]["0"]["LongMessage"] != null || singleitemdata["Errors"]["0"]["LongMessage"] != "" ){
        displayMessages(singleitemdata["Errors"]["0"]["LongMessage"]);
      }
  } else {
    displayResultsSingleItem(singleitemdata);
  }
}
function displayResultsSingleItem(data){
  var heading = document.getElementById("ihead");
  heading.innerHTML = "<h1 align=\"center\">Item Details</h1>";
  var table = document.getElementById("resultTable");
  table.innerHTML = "";
  table.style.width = "700px";
  table.setAttribute("border", "1px solid black");
  if(data["Item"] == undefined || data["Item"] == null || data["Item"]=="")
  {
     heading.innerHTML = "<h2 align=\"center\">No Item Details found</h2>";
  }
  else
  {
    if(data["Item"]["PictureURL"] != undefined || data["Item"]["PictureURL"]["0"] != undefined)
    {
      var row = table.insertRow();
      var cell = row.insertCell();
      cell.innerHTML = "<b>Photo</b>";
      var cell = row.insertCell();
      cell.innerHTML = "<img height=\"150px\" width=\"150px\" src=" + data["Item"]["PictureURL"]["0"] + "</img>";
    }
    if (data["Item"]["Title"] != undefined)
    {
      var row = table.insertRow();
      var cell = row.insertCell();
      cell.innerHTML = "<b>Title</b>";
      var cell = row.insertCell();
      cell.innerHTML = data["Item"]["Title"] ;
      cell.style.wordBreak = "break-all";
    }

    if (data["Item"]["CurrentPrice"] != undefined || data["Item"]["CurrentPrice"]["Value"] != undefined)
    {
      var row = table.insertRow();
      var cell = row.insertCell();
      cell.innerHTML = "<b>Price</b>";
      var cell = row.insertCell();
      if(data["Item"]["CurrentPrice"]["CurrencyID"] != undefined){
        cell.innerHTML = data["Item"]["CurrentPrice"]["Value"] +" "+ data["Item"]["CurrentPrice"]["CurrencyID"] ;
        cell.style.wordBreak = "break-all";}
      else{
        cell.innerHTML = data["Item"]["CurrentPrice"]["Value"];
        cell.style.wordBreak = "break-all";}
    }
    if (data["Item"]["Location"] != undefined) {
      var row = table.insertRow();
      var cell = row.insertCell();
      cell.innerHTML = "<b>Location</b>";
      var cell = row.insertCell();
      if(data["Item"]["PostalCode"] == undefined){
        cell.innerHTML = data["Item"]["Location"];
        cell.style.wordBreak = "break-all";
      }else{
        cell.innerHTML = data["Item"]["Location"] +","+ data["Item"]["PostalCode"];
        cell.style.wordBreak = "break-all";}
    }
    if (data["Item"]["Seller"] != undefined || data["Item"]["Seller"]["UserID"] != undefined) {
      var row = table.insertRow();
      var cell = row.insertCell();
      cell.style.wordBreak = "break-all";
      cell.innerHTML = "<b>Seller</b>";
      var cell = row.insertCell();
      cell.innerHTML = data["Item"]["Seller"]["UserID"];
      cell.style.wordBreak = "break-all";
    }
    if (data["Item"]["ReturnPolicy"] != undefined) {
      var row = table.insertRow();
      var cell = row.insertCell();
      cell.style.wordBreak = "break-all";
      cell.innerHTML = "<b>ReturnPolicy</b>";
      var cell = row.insertCell();
      if(data["Item"]["ReturnPolicy"]["ReturnsWithin"] !=undefined )
      {  cell.innerHTML = data["Item"]["ReturnPolicy"]["ReturnsAccepted"] + "$nbsp within &nbsp" + data["Item"]["ReturnPolicy"]["ReturnsWithin"];
        cell.style.wordBreak = "break-all";
      }else{
        cell.innerHTML = data["Item"]["ReturnPolicy"]["ReturnsAccepted"];
        cell.style.wordBreak = "break-all";}
    }
    if (data["Item"]["ItemSpecifics"] != undefined || data["Item"]["ItemSpecifics"]["NameValueList"] != undefined ) {
      for(var specifics in data["Item"]["ItemSpecifics"]["NameValueList"])
      {
        var row = table.insertRow();
        var cell = row.insertCell();
        cell.innerHTML = "<b>"+data["Item"]["ItemSpecifics"]["NameValueList"][specifics]["Name"]+"</b>";
        cell.style.wordBreak = "break-all";
        var cell = row.insertCell();
        cell.innerHTML = data["Item"]["ItemSpecifics"]["NameValueList"][specifics]["Value"]["0"];
        cell.style.wordBreak = "break-all";
      }
    }
  }  //variable for seller msg
  var divbtns = document.getElementById("forbtns");
  divbtns.innerHTML = "";
  var sellermsgtitle = document.createElement("p");
  sellermsgtitle.textContent = "click to show seller message";
  sellermsgtitle.style.marginBottom = 0;
  sellermsgtitle.style.color="Lightgrey";
  sellermsgtitle.style.fontWeight = "bold";
  divbtns.appendChild(sellermsgtitle);
  imgbtn = document.createElement("input");
  imgbtn.id = "btnforseller";
  imgbtn.setAttribute("type","image");
  imgbtn.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_down.png");
  imgbtn.style.width = 35;
  imgbtn.style.height = 20;
  imgbtn.style.marginBottom = "5px";
  divbtns.appendChild(imgbtn);
  var x = document.createElement("IFRAME");
  x.onload = function(){
    x.style.height = Math.max(x.contentDocument.body.scrollHeight, x.contentDocument.body.offsetHeight,
    x.contentDocument.documentElement.clientHeight, x.contentDocument.documentElement.scrollHeight, x.contentDocument.documentElement.offsetHeight);
  }
  x.style.display = "none";
  x.frameBorder="0" ;
  x.scrolling="no";
  divbtns.appendChild(x);
  //variables for similar items
  divbtns2 = document.getElementById("forbtns2");
  divbtns2.innerHTML = "";
  simitemstitle = document.createElement("p");
  simitemstitle.textContent = "click to show similar items";
  simitemstitle.style.marginBottom = 0;
  simitemstitle.style.color="Lightgrey";
  simitemstitle.style.fontWeight = "bold";
  divbtns2.appendChild(simitemstitle);
  imgbtnsi = document.createElement("input");
  imgbtnsi.id = "btnforsi";
  imgbtnsi.setAttribute("type","image");
  imgbtnsi.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_down.png");
  imgbtnsi.style.width = 35;
  imgbtnsi.style.height = 20;
  divbtns2.appendChild(imgbtnsi);
  var divsim = document.createElement("div");
  divsim.style.display = "none";
  var similarItemsTable = document.createElement("table");
  similarItemsTable.style.borderCollapse = "collapse";
  x.style.width = "900px";
  x.style.margin = "auto";
  imgbtn.addEventListener("click", function(){
  if (x.style.display === "none") {
          x.style.display = "block"; //Showing seller msg section
          if( data["Item"] == undefined || data["Item"]["Description"] == undefined)
          {
              x.srcdoc = "<div style=\"background-color:Lightgrey; margin:auto; text-align:center\"><b>No Seller Message</b></div>";
          } else {
          //    x.src=  data["Item"]["Description"]; //"http://www.google.com";
              x.srcdoc = data["Item"]["Description"];
              //x.contentWindow.document.body.offsetHeight;//x.contentDocument.body.scrollHeight;
          }
          sellermsgtitle.textContent = "click to hide seller message"; //checking btn props
          imgbtn.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_up.png");
          //Minimising similarItems section when seller message it expanded
          divsim.style.display = "none";
          simitemstitle.textContent = "click to show similar items";
          imgbtnsi.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_down.png");
          similarItemsTable.innerHTML = "";
      } else {
          x.style.display = "none";
          sellermsgtitle.textContent = "click to show seller message";
          imgbtn.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_down.png");
      }
  });
  imgbtnsi.addEventListener("click", function(){
  if (divsim.style.display === "none")
  {
      divsim.style.overflowX = "auto";
      divsim.style.overflowY = "hidden";
      divsim.style.width = "800px";
      divsim.style.margin="auto";
      divsim.style.marginTop = "5px";
      divsim.style.border = "2px solid Lightgrey";
      //..showing similar items section
      divsim.style.display = "block";
      simitemstitle.textContent = "click to hide similar items";
      imgbtnsi.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_up.png");
      similarItemsTable.innerHTML = "";
      //Minimising the seller message section when similar items is clicked
      x.style.display = "none";
      sellermsgtitle.textContent = "click to show seller message";
      imgbtn.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_down.png");
      //similar items request begins here
      var request = new XMLHttpRequest();
      var itemIdparam = data["Item"]["ItemID"];
      var similaritemssurl ="/HW6.php?similarItems=true&itemId=" +itemIdparam;
      request.open("GET",similaritemssurl, false);
      request.send();
      var similarItems = JSON.parse(request.responseText);
      var tocheck = similarItems["getSimilarItemsResponse"];
      if (typeof tocheck == undefined || tocheck == "" || tocheck == null || similarItems["getSimilarItemsResponse"]["itemRecommendations"] == undefined ||
      similarItems["getSimilarItemsResponse"]["itemRecommendations"] == null || similarItems["getSimilarItemsResponse"]["itemRecommendations"] == "" ||
      similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"] == undefined || similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"] == null ||
      similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"] == "" || similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"]["0"] == undefined ||
      similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"]["0"] == null || similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"]["0"] == "" ) {
            divsim.innerHTML = "<div style=\"border: 1px solid Lightgrey ; margin: 7px\"><h4>No Similar Items Found</h4><div>";
            divsim.style.textAlign = "center";
            divbtns2.appendChild(divsim);
      } else {
            //dispalying similar items
            divbtns2.appendChild(divsim);
            var row = similarItemsTable.insertRow();
            row.style.textAlign = "center";
            row.style.margin = "0px";
            for(var item in similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"])
            {
                var cell = row.insertCell();
                cell.style.border = "0";
                cell.style.paddingLeft = "40px";
                cell.style.paddingRight = "40px";
                var itemId = similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"][item]["itemId"];
                cell.innerHTML = "<img width=125px src=\"" + similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"][item]["imageURL"] +"\"></img>"+
                "<a  style=\"text-decoration:none;color:black;\" id=\"itemdetails\" href=\"javascript:getSingleItem(" + itemId + ")\" ><p>"+  similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"][item]["title"] +"<p></a>" +
                "<p>$<b>"+ similarItems["getSimilarItemsResponse"]["itemRecommendations"]["item"][item]["buyItNowPrice"]["__value__"] +"</b></p>";
            }
            divsim.appendChild(similarItemsTable);
      }
  } else {
      divsim.style.display = "none";
      simitemstitle.textContent = "click to show similar items";
      imgbtnsi.setAttribute("src","http://csci571.com/hw/hw6/images/arrow_down.png");
  }
  });

}//end of displayResultsSingleItem()
function displayResults(data){
  var headers = ["Index", "Photo", "Name", "Price", "Zip&nbspcode", "Condition" , "Shipping&nbspOption"];
  var table = document.getElementById("resultTable");
  table.innerHTML ="";
  table.style.width = "1000px";
  table.style.height = "200px"
  table.setAttribute("border","1px solid black");
  table.style.borderCollapse = "collapse";
  var tableHeader = table.createTHead();
  var tblheaderRow = tableHeader.insertRow();
  for (var i in headers) {
    var tblHeaderVal = tblheaderRow.insertCell();
    tblHeaderVal.innerHTML = "<b>"+headers[i]+"</b>";
    tblHeaderVal.style.textAlign = "center";
  }
  var index = 0;
  for (var searchResults in data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"])
  {
    index++;
    var tableRow = table.insertRow();
    //tableRow.style.height = "200px";
    var tablecell =tableRow.insertCell();
    tablecell.innerHTML = index;
    if(data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["galleryURL"] == undefined)
    {
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "N/A";
    }else{
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "<img src=\"" + data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["galleryURL"] +"\">";
    }
    if(data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["title"] == undefined)
    {
        var tablecell =  tableRow.insertCell();
        if(data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["itemId"]["0"] != undefined)
        {
          var itemId = data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["itemId"]["0"];
          tablecell.innerHTML =  "<a style=\"text-decoration:none;color:black;\" id=\"itemdetails\" href=\"javascript:getSingleItem(" + itemId + ")\">"+ NA + "</a>" ;
        }
        else
          tablecell.innerHTML = "N/A";
    }else{
        var tablecell =  tableRow.insertCell();
        var itemId = data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["itemId"]["0"];
        tablecell.innerHTML =  "<a style=\"text-decoration:none;color:black;\" id=\"itemdetails\" href=\"javascript:getSingleItem(" + itemId + ")\">"+ data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["title"]    + "</a>" ;
    }
    if (data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["sellingStatus"] == undefined || data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["sellingStatus"]["0"] == undefined
      || data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["sellingStatus"]["0"]["currentPrice"] == undefined
      || data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["sellingStatus"]["0"]["currentPrice"]["0"] == undefined
      || data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["sellingStatus"]["0"]["currentPrice"]["0"]["__value__"] == undefined)
    {
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "N/A";
    }else{
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "$" + data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["sellingStatus"]["0"]["currentPrice"]["0"]["__value__"];
    }
    if (data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["postalCode"] == undefined || data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["postalCode"]["0"] == undefined) {
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "N/A";
    }else{
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["postalCode"]["0"];
    }
    if (data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["condition"] == undefined ||
          data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["condition"]["0"] == undefined ||
          data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["condition"]["0"]["conditionDisplayName"]  == undefined)
    {
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "N/A";
    }else{
        var tablecell =  tableRow.insertCell();
        var x = data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["condition"]["0"]["conditionDisplayName"];
        if (x=="")
          tablecell.innerHTML = "N/A";
        else
          tablecell.innerHTML =  x;
    }
    if (data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["shippingInfo"] == undefined ||
       data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["shippingInfo"]["0"] == undefined ||
       data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["shippingInfo"]["0"]["shippingServiceCost"] == undefined ||
      data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["shippingInfo"]["0"]["shippingServiceCost"]["0"] == undefined ||
     data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"] == undefined)
    {
        var tablecell =  tableRow.insertCell();
        tablecell.innerHTML = "N/A";
    }else{
        var tablecell =  tableRow.insertCell();
        var x = data["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"][searchResults]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"];
        if (x == "0.0" || x == "0")
          tablecell.innerHTML = "Free Shipping";
        else if (x == "")
          tablecell.innerHTML = "N/A";
        else
          tablecell.innerHTML = "$" + x;
    }
  }
}
</script>
</head>
<body onload="event.preventDefault();findgeoLocation();">
  <form action="javascript:sendInfo(this.form)" name="search_form" id="search_form"><p>Product Search</p>
    <div id="group"><label for="keyword"><b>Keyword</b></label>
      <input type="text" id="keyword" name="keyword" value="" required></input></br>
    <label for="category"><b>Category</b></label>
      <select name="category" id="category">
        <option value="All" selected>All Categories</option>
        <option value="Art">Art</option>
        <option value="Baby">Baby</option>
        <option value="Books">Books</option>
        <option value="Clothing">Clothing</option>
        <option value="Shoes & Accessories">Shoes & Accessories</option>
        <option value="Computers/Tablets & Networking">Computers/Tablets & Networking</option>
        <option value="Health & Beauty">Health & Beauty</option>
        <option value="Music">Music</option>
        <option value="Video Games & Consoles">Video Games & Consoles</option>
      </select></br>
    <label for="condition"><b>Condition</b></label>
      <input id="new" type="checkbox" name="condition" value="New">New</input>
      <input id="used" type="checkbox" name="condition" value="Used">Used</input>
      <input id="none" type="checkbox" name="condition" value="Unspecified">Unspecified</input></br>
    <label for="shipping_options"><b>Shipping Options</b></label>
      <input id="local" type="checkbox" name="shipping_options" value="Local Pickup">Local Pickup</input>
      <input id="ship" type="checkbox" name="shipping_options" value="Free Shipping">Free Shipping</input></br>
    <input type="checkbox" id="nearbysearch" name="enable_nearby_search" value="enable_nearby_search" onchange="togglefields(this.form.nearbysearch)" autocomplete="off"><b>Enable Nearby Search</b>
    <input class="toenable" id="miles" type="textarea" name="distance" placeholder="10" value = "10" disabled><label for="distance"><b>miles from</b></label>
    <input class="toenable" id="here" type="radio" name="loc" value="Here" onchange="toggleTextfield(this.form.textzip)" disabled checked="true"><label for="loc">Here</label></br>
    <input class="toenable" id="zip" type="radio" name="loc" value="zipcode" onchange="toggleTextfield(this.form.textzip)" disabled >
    <input class="toenable" id="textzip" type="textarea" name="loc" placeholder="zip code" disabled required>
    </div>
    <div id="buttons">
      <input type="submit" id="search" name="search" value="Search" disabled></input>
      <input type="button" id="clear" name="clear" value="Clear" onclick="clearForm(this.form)"></input>
    </div>
  </form>
  <div id="ihead"></div>
  <table style="margin:auto" id="resultTable"></table>
  <div style="text-align:center" id="forbtns">
  </div>
  <div style="text-align:center" id="forbtns2">
  </div>

  <script type="text/javascript" src="http://ip-api.com/json?callback=findgeoLocation">
  </script>

</body>
</html>
